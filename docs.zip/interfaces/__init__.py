"""LeakGuard Interfaces Layer"""
